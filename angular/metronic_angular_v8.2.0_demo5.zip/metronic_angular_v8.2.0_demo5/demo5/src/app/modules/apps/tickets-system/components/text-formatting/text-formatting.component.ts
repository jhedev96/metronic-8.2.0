import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-text-formatting',
  templateUrl: './text-formatting.component.html',
  styleUrls: ['./text-formatting.component.scss']
})
export class TextFormattingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
