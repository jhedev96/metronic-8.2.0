import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-reply",
  templateUrl: "./reply.component.html",
  styleUrls: ["./reply.component.scss"],
})
export class ReplyComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {}
}
