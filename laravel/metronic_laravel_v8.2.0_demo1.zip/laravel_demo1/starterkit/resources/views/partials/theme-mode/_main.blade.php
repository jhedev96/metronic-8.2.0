<!--begin::Menu toggle-->
<a href="#" class="btn btn-icon btn-custom btn-icon-muted btn-active-light btn-active-color-primary w-30px h-30px w-md-40px h-md-40px" data-kt-menu-trigger="{default:'click', lg: 'hover'}" data-kt-menu-attach="parent" data-kt-menu-placement="bottom-end">{!! getIcon('night-day', 'theme-light-show fs-2 fs-lg-1') !!} {!! getIcon('moon', 'theme-dark-show fs-2 fs-lg-1') !!}</a>
<!--begin::Menu toggle-->
@include('partials/theme-mode/__menu')