<x-system-layout>
    @include('pages.system.not_found')
</x-system-layout>
