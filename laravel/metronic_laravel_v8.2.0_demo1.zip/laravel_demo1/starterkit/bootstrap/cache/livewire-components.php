<?php return array (
  'permission.permission-modal' => 'App\\Http\\Livewire\\Permission\\PermissionModal',
  'permission.role-list' => 'App\\Http\\Livewire\\Permission\\RoleList',
  'permission.role-modal' => 'App\\Http\\Livewire\\Permission\\RoleModal',
  'user.add-user-modal' => 'App\\Http\\Livewire\\User\\AddUserModal',
);