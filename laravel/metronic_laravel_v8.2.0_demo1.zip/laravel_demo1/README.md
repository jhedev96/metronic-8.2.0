# Metronic - Bootstrap 5 Admin Dashboard Theme

- The other demos can be downloaded online from [Metronic Downloads](//devs.keenthemes.com/metronic)

- For a quick start please check [Online documentation page](//preview.keenthemes.com/laravel/metronic/docs/)

- For any theme related questions please contact our [Theme Support](//keenthemes.com/support/)

- Using Metronic in a new project or for a new client? Purchase a new license https://1.envato.market/EA4JP or watch https://youtu.be/HJ3RNhoI24A to find out more information about licenses.

- Stay tuned for updates via [Twitter](//www.twitter.com/keenthemes) and [Instagram](//www.instagram.com/keenthemes) and
  check our marketplace for more amazing products: [Keenthemes Marketplace](//keenthemes.com/)

Happy coding with Metronic!
