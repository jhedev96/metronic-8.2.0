import { Component } from '@angular/core';

@Component({
  selector: 'app-main-modal',
  templateUrl: './main-modal.component.html',
})
export class MainModalComponent {
  constructor() {}
}
