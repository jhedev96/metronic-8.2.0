<!--begin::Modals-->
@include('partials/modals/_upgrade-plan')

@include('partials/modals/create-app/_main')

@include('partials/modals/create-campaign/_main')

@include('partials/modals/create-project/_main')

@include('partials/modals/_new-target')

@include('partials/modals/_view-users')

@include('partials/modals/users-search/_main')

@include('partials/modals/_invite-friends')
<!--end::Modals-->
