Metronic Demo 1 comes with 4 main layout options:

Dark Sidebar:
- In "Views/__ViewStart.cshtml" set "DefaultDarkSidebar.cshtml" as default layout template.

Light Sidebar:
- In "Views/__ViewStart.cshtml" set "DefaultLightSidebar.cshtml" as default layout template.

Dark Header:
- In "Views/__ViewStart.cshtml" set "DefaultDarkHeader.cshtml" as default layout template.

Light Header:
- In "Views/__ViewStart.cshtml" set "DefaultLightHeader.cshtml" as default layout template.