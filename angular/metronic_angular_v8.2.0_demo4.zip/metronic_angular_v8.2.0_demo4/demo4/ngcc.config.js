module.exports = {
  packages: {
    "ngx-highlightjs": {
      ignorableDeepImportMatchers: [/highlight.js\//],
    },
  },
};
