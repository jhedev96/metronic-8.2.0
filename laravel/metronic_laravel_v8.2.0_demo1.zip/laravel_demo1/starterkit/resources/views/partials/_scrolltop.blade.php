<!--begin::Scrolltop-->
<div id="kt_scrolltop" class="scrolltop" data-kt-scrolltop="true">{!! getIcon('arrow-up', '') !!}</div>
<!--end::Scrolltop-->