import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tables-widget13',
  templateUrl: './tables-widget13.component.html',
})
export class TablesWidget13Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
